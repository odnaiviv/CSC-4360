//
//  MultipleViewsApp.swift
//  MultipleViews
//
//  Created by user247404 on 10/26/23.
//

import SwiftUI

@main
struct MultipleViewsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
