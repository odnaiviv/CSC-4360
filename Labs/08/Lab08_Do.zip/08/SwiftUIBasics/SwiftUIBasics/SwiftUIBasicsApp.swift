//
//  SwiftUIBasicsApp.swift
//  SwiftUIBasics
//
//  Created by user247404 on 10/26/23.
//

import SwiftUI

@main
struct SwiftUIBasicsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
