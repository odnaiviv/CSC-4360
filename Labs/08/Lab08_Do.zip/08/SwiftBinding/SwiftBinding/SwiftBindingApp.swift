//
//  SwiftBindingApp.swift
//  SwiftBinding
//
//  Created by user247404 on 10/26/23.
//

import SwiftUI

@main
struct SwiftBindingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
