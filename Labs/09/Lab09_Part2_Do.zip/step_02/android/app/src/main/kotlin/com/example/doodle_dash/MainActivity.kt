package com.example.doodle_dash

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
